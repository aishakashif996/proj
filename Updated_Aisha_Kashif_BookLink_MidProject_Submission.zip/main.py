#BookLink - Book Exchange & Donation System
import tkinter as tk
from tkinter import messagebox

books = []

def donate_book():
    donor = donor_entry.get()
    contact = contact_entry.get()
    title = book_entry.get()
    subject = subject_entry.get()
    condition = condition_var.get()

    if donor == "" or contact == "" or title == "" or subject == "":
        messagebox.showerror("Error", "Please fill all fields")
        return

    books.append({
        "donor": donor,
        "contact": contact,
        "title": title,
        "subject": subject,
        "condition": condition
    })

    messagebox.showinfo("Success", "Book Donated Successfully!")

    donor_entry.delete(0, tk.END)
    contact_entry.delete(0, tk.END)
    book_entry.delete(0, tk.END)
    subject_entry.delete(0, tk.END)

def search_book():
    search_title = search_entry.get().lower()

    found = False

    for book in books:
        if search_title in book["title"].lower():
            result_label.config(
                text=f"Book Found!\n\n"
                     f"Book Title: {book['title']}\n"
                     f"Subject: {book['subject']}\n"
                     f"Condition: {book['condition']}\n"
                     f"Donor: {book['donor']}\n"
                     f"Contact No: {book['contact']}"
            )
            found = True
            break

    if not found:
        result_label.config(text="Book Not Available")

root = tk.Tk()
root.title("BookLink")
root.geometry("500x650")

tk.Label(
    root,
    text="BookLink - Book Exchange & Donation System",
    font=("Arial", 16, "bold")
).pack(pady=10)

# Donor Name
tk.Label(root, text="Donor Name").pack()
donor_entry = tk.Entry(root, width=30)
donor_entry.pack()

# Donor Contact Number
tk.Label(root, text="Donor Contact Number").pack()
contact_entry = tk.Entry(root, width=30)
contact_entry.pack()

# Book Title
tk.Label(root, text="Book Title").pack()
book_entry = tk.Entry(root, width=30)
book_entry.pack()

# Subject
tk.Label(root, text="Subject").pack()
subject_entry = tk.Entry(root, width=30)
subject_entry.pack()

# Book Condition
tk.Label(root, text="Book Condition").pack()

condition_var = tk.StringVar(value="Good")

tk.Radiobutton(
    root,
    text="New",
    variable=condition_var,
    value="New"
).pack()

tk.Radiobutton(
    root,
    text="Good",
    variable=condition_var,
    value="Good"
).pack()

tk.Radiobutton(
    root,
    text="Used",
    variable=condition_var,
    value="Used"
).pack()

# Donate Button
tk.Button(
    root,
    text="Donate Book",
    command=donate_book
).pack(pady=10)

# Search Section
tk.Label(root, text="Search Book").pack()

search_entry = tk.Entry(root, width=30)
search_entry.pack()

tk.Button(
    root,
    text="Find Book",
    command=search_book
).pack(pady=10)

# Result Label
result_label = tk.Label(
    root,
    text="",
    font=("Arial", 11),
    justify="left"
)
result_label.pack(pady=20)

root.mainloop()
