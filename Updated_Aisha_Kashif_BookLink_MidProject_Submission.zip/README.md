
# BookLink

BookLink is a Python GUI-based Book Donation and Exchange System.

## Features
- Donate books
- Store donor contact details
- Record book condition
- Search donated books

## Technologies Used
- Python
- Tkinter

## Run the Project
python main.py
